// script.js — main app glue: tabs, storage, gallery, chat integration
const STORAGE_PREFIX = "fantasia_v3_";
const KEY_USER = STORAGE_PREFIX + "user";
const KEY_CHARS = STORAGE_PREFIX + "chars";
const KEY_SELECTED = STORAGE_PREFIX + "selected";
const KEY_LOG_PREFIX = STORAGE_PREFIX + "log_";

let appState = {
  user: null,
  chars: [],
  selected: null,
  lang: "pt-BR",
  tts: true
};

function saveChars(){ localStorage.setItem(KEY_CHARS, JSON.stringify(appState.chars)); }
function loadChars(){ const s = localStorage.getItem(KEY_CHARS); return s? JSON.parse(s): []; }
function saveUser(){ if(appState.user) localStorage.setItem(KEY_USER, appState.user); else localStorage.removeItem(KEY_USER); }
function loadUser(){ return localStorage.getItem(KEY_USER) || null; }

function init(){
  // splash
  document.getElementById("startBtn").onclick = ()=>{
    document.getElementById("splash").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    boot();
  };
}

function boot(){
  // load state
  appState.user = loadUser();
  appState.chars = loadChars();
  appState.lang = localStorage.getItem(STORAGE_PREFIX+"lang") || "pt-BR";
  document.getElementById("langSelect").value = appState.lang;
  document.getElementById("userLabel").innerText = appState.user || "Convidado";
  bindUI();
  renderGallery();
  renderPreview();
  tryAutoRestore();
}

function bindUI(){
  // tabs
  document.querySelectorAll(".tabs .tab").forEach(btn=>{
    btn.onclick = ()=> {
      if(btn.classList.contains("locked")) { alert("🔒 Faça login e crie ou selecione um personagem para desbloquear o chat."); return; }
      document.querySelectorAll(".tabs .tab").forEach(t=>t.classList.remove("active"));
      btn.classList.add("active");
      const tab = btn.dataset.tab;
      document.querySelectorAll(".panel").forEach(p=>p.classList.remove("active"));
      document.getElementById(tab).classList.add("active");
      if(tab==="chat") openChat();
    };
  });
  // create actions
  document.getElementById("createBtn").onclick = createCharacterFromForm;
  document.getElementById("randomBtn").onclick = createRandomChar;
  document.getElementById("clearBtn").onclick = ()=> { document.getElementById("charName").value=""; document.getElementById("charDesc").value=""; };
  document.getElementById("genAutoAvatar").onclick = ()=> { generatePreviewAvatar(); };
  document.getElementById("avatarUpload").onchange = handleAvatarUpload;
  document.getElementById("langSelect").onchange = (e)=> { appState.lang = e.target.value; localStorage.setItem(STORAGE_PREFIX+"lang", appState.lang); }
  document.getElementById("logoutBtn").onclick = ()=> { appState.user=null; saveUser(); document.getElementById("userLabel").innerText="Convidado"; };
  document.getElementById("sendBtn").onclick = sendMessage;
  document.getElementById("userInput").onkeydown = (e)=> { if(e.key==="Enter") sendMessage(); };
  document.getElementById("ttsToggle").onclick = ()=> { appState.tts = !appState.tts; document.getElementById("ttsToggle").innerText = appState.tts? "🔊":"🔈"; };
  document.getElementById("exportLog").onclick = ()=> { exportLog(appState.selected); };
}

function renderGallery(){
  const gallery = document.getElementById("galleryList");
  gallery.innerHTML = "";
  const presets = getPresets();
  presets.forEach((p, i)=>{
    const tpl = document.getElementById("charCardTpl");
    const node = tpl.content.cloneNode(true);
    const card = node.querySelector(".char-card");
    const avatarEl = card.querySelector(".char-avatar");
    avatarEl.innerHTML = `<img src="${p.avatar}" />`;
    card.querySelector(".char-name").innerText = p.name;
    card.querySelector(".char-meta").innerText = `${p.style} • ${p.emotion}`;
    const useBtn = node.querySelector(".useBtn");
    useBtn.onclick = ()=> { usePreset(p); };
    gallery.appendChild(node);
  });
  // also show user chars
  const userChars = appState.chars || [];
  userChars.forEach((c)=>{
    const tpl = document.getElementById("charCardTpl");
    const node = tpl.content.cloneNode(true);
    const card = node.querySelector(".char-card");
    const avatarEl = card.querySelector(".char-avatar");
    avatarEl.innerHTML = `<img src="${c.avatar}" />`;
    card.querySelector(".char-name").innerText = c.name;
    card.querySelector(".char-meta").innerText = `${c.style} • ${c.emotion}`;
    const useBtn = node.querySelector(".useBtn");
    useBtn.onclick = ()=> { selectCharacter(c.id); };
    gallery.appendChild(node);
  });
}

function getPresets(){
  // auto-generated large presets list
  return [
{ name:"OC_Dugwnp", style:"frio", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Dugwnp','frio',240) },
{ name:"OC_Nfvlwz", style:"brincalhão", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Nfvlwz','brincalhão',240) },
{ name:"OC_Whsonf", style:"engraçado", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Whsonf','engraçado',240) },
{ name:"OC_Kctkqd", style:"poético", emotion:"alegre", avatar: makeAvatarSVG('OC_Kctkqd','poético',240) },
{ name:"OC_Kjvybs", style:"romântico", emotion:"alegre", avatar: makeAvatarSVG('OC_Kjvybs','romântico',240) },
{ name:"OC_Vgonpg", style:"calmo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Vgonpg','calmo',240) },
{ name:"OC_Wukjcc", style:"frio", emotion:"alegre", avatar: makeAvatarSVG('OC_Wukjcc','frio',240) },
{ name:"OC_Hurjmu", style:"romântico", emotion:"sereno", avatar: makeAvatarSVG('OC_Hurjmu','romântico',240) },
{ name:"OC_Ovjivf", style:"frio", emotion:"tímido", avatar: makeAvatarSVG('OC_Ovjivf','frio',240) },
{ name:"OC_Iristc", style:"arrogante", emotion:"sombrio", avatar: makeAvatarSVG('OC_Iristc','arrogante',240) },
{ name:"OC_Zstrsu", style:"engraçado", emotion:"intenso", avatar: makeAvatarSVG('OC_Zstrsu','engraçado',240) },
{ name:"OC_Fpqudd", style:"misterioso", emotion:"sombrio", avatar: makeAvatarSVG('OC_Fpqudd','misterioso',240) },
{ name:"OC_Klsvgj", style:"frio", emotion:"tímido", avatar: makeAvatarSVG('OC_Klsvgj','frio',240) },
{ name:"OC_Vsofwp", style:"calmo", emotion:"alegre", avatar: makeAvatarSVG('OC_Vsofwp','calmo',240) },
{ name:"OC_Wbmjos", style:"arrogante", emotion:"intenso", avatar: makeAvatarSVG('OC_Wbmjos','arrogante',240) },
{ name:"OC_Jwtwqv", style:"calmo", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Jwtwqv','calmo',240) },
{ name:"OC_Ctoeye", style:"romântico", emotion:"pensativo", avatar: makeAvatarSVG('OC_Ctoeye','romântico',240) },
{ name:"OC_Onpugn", style:"arrogante", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Onpugn','arrogante',240) },
{ name:"OC_Qcwyuv", style:"misterioso", emotion:"tímido", avatar: makeAvatarSVG('OC_Qcwyuv','misterioso',240) },
{ name:"OC_Jbzrdk", style:"calmo", emotion:"melancólico", avatar: makeAvatarSVG('OC_Jbzrdk','calmo',240) },
{ name:"OC_Izorer", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Izorer','engraçado',240) },
{ name:"OC_Rtztla", style:"romântico", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Rtztla','romântico',240) },
{ name:"OC_Rlafer", style:"romântico", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Rlafer','romântico',240) },
{ name:"OC_Biwsrt", style:"fofo", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Biwsrt','fofo',240) },
{ name:"OC_Ipejcl", style:"fofo", emotion:"melancólico", avatar: makeAvatarSVG('OC_Ipejcl','fofo',240) },
{ name:"OC_Kdnjnt", style:"frio", emotion:"alegre", avatar: makeAvatarSVG('OC_Kdnjnt','frio',240) },
{ name:"OC_Enodyb", style:"calmo", emotion:"alegre", avatar: makeAvatarSVG('OC_Enodyb','calmo',240) },
{ name:"OC_Pnudpq", style:"brincalhão", emotion:"sombrio", avatar: makeAvatarSVG('OC_Pnudpq','brincalhão',240) },
{ name:"OC_Gtvmwd", style:"misterioso", emotion:"sereno", avatar: makeAvatarSVG('OC_Gtvmwd','misterioso',240) },
{ name:"OC_Iujgrd", style:"misterioso", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Iujgrd','misterioso',240) },
{ name:"OC_Vmujjv", style:"brincalhão", emotion:"intenso", avatar: makeAvatarSVG('OC_Vmujjv','brincalhão',240) },
{ name:"OC_Vzyzfs", style:"fofo", emotion:"sereno", avatar: makeAvatarSVG('OC_Vzyzfs','fofo',240) },
{ name:"OC_Jhezeq", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Jhezeq','engraçado',240) },
{ name:"OC_Ultwbd", style:"brincalhão", emotion:"sombrio", avatar: makeAvatarSVG('OC_Ultwbd','brincalhão',240) },
{ name:"OC_Exzdhh", style:"engraçado", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Exzdhh','engraçado',240) },
{ name:"OC_Lagogo", style:"frio", emotion:"alegre", avatar: makeAvatarSVG('OC_Lagogo','frio',240) },
{ name:"OC_Bcxfth", style:"arrogante", emotion:"melancólico", avatar: makeAvatarSVG('OC_Bcxfth','arrogante',240) },
{ name:"OC_Ktbduc", style:"calmo", emotion:"tímido", avatar: makeAvatarSVG('OC_Ktbduc','calmo',240) },
{ name:"OC_Ibxmgo", style:"misterioso", emotion:"intenso", avatar: makeAvatarSVG('OC_Ibxmgo','misterioso',240) },
{ name:"OC_Tqpuwd", style:"engraçado", emotion:"alegre", avatar: makeAvatarSVG('OC_Tqpuwd','engraçado',240) },
{ name:"OC_Ofscxr", style:"brincalhão", emotion:"melancólico", avatar: makeAvatarSVG('OC_Ofscxr','brincalhão',240) },
{ name:"OC_Agbtoy", style:"misterioso", emotion:"alegre", avatar: makeAvatarSVG('OC_Agbtoy','misterioso',240) },
{ name:"OC_Aunqcs", style:"possessivo", emotion:"tímido", avatar: makeAvatarSVG('OC_Aunqcs','possessivo',240) },
{ name:"OC_Dtkbve", style:"calmo", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Dtkbve','calmo',240) },
{ name:"OC_Vuuhrt", style:"romântico", emotion:"melancólico", avatar: makeAvatarSVG('OC_Vuuhrt','romântico',240) },
{ name:"OC_Mtxemx", style:"brincalhão", emotion:"alegre", avatar: makeAvatarSVG('OC_Mtxemx','brincalhão',240) },
{ name:"OC_Lxzdkx", style:"brincalhão", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Lxzdkx','brincalhão',240) },
{ name:"OC_Brqqpn", style:"possessivo", emotion:"alegre", avatar: makeAvatarSVG('OC_Brqqpn','possessivo',240) },
{ name:"OC_Qwpnhl", style:"fofo", emotion:"feliz", avatar: makeAvatarSVG('OC_Qwpnhl','fofo',240) },
{ name:"OC_Ewdpdo", style:"possessivo", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Ewdpdo','possessivo',240) },
{ name:"OC_Ahdevw", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Ahdevw','engraçado',240) },
{ name:"OC_Ehifhl", style:"possessivo", emotion:"alegre", avatar: makeAvatarSVG('OC_Ehifhl','possessivo',240) },
{ name:"OC_Kyjqgf", style:"fofo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Kyjqgf','fofo',240) },
{ name:"OC_Edkfpi", style:"brincalhão", emotion:"feliz", avatar: makeAvatarSVG('OC_Edkfpi','brincalhão',240) },
{ name:"OC_Ixshlr", style:"calmo", emotion:"sereno", avatar: makeAvatarSVG('OC_Ixshlr','calmo',240) },
{ name:"OC_Hysvhu", style:"engraçado", emotion:"alegre", avatar: makeAvatarSVG('OC_Hysvhu','engraçado',240) },
{ name:"OC_Sqkwej", style:"possessivo", emotion:"sombrio", avatar: makeAvatarSVG('OC_Sqkwej','possessivo',240) },
{ name:"OC_Peewck", style:"romântico", emotion:"sombrio", avatar: makeAvatarSVG('OC_Peewck','romântico',240) },
{ name:"OC_Lziwdr", style:"arrogante", emotion:"feliz", avatar: makeAvatarSVG('OC_Lziwdr','arrogante',240) },
{ name:"OC_Pjvjxh", style:"romântico", emotion:"feliz", avatar: makeAvatarSVG('OC_Pjvjxh','romântico',240) },
{ name:"OC_Nreart", style:"engraçado", emotion:"intenso", avatar: makeAvatarSVG('OC_Nreart','engraçado',240) },
{ name:"OC_Suwypa", style:"brincalhão", emotion:"feliz", avatar: makeAvatarSVG('OC_Suwypa','brincalhão',240) },
{ name:"OC_Dvcvqo", style:"brincalhão", emotion:"intenso", avatar: makeAvatarSVG('OC_Dvcvqo','brincalhão',240) },
{ name:"OC_Vvoaud", style:"misterioso", emotion:"alegre", avatar: makeAvatarSVG('OC_Vvoaud','misterioso',240) },
{ name:"OC_Gxkruo", style:"arrogante", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Gxkruo','arrogante',240) },
{ name:"OC_Qznzcj", style:"engraçado", emotion:"sombrio", avatar: makeAvatarSVG('OC_Qznzcj','engraçado',240) },
{ name:"OC_Pxshkh", style:"possessivo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Pxshkh','possessivo',240) },
{ name:"OC_Prcwos", style:"frio", emotion:"sereno", avatar: makeAvatarSVG('OC_Prcwos','frio',240) },
{ name:"OC_Prvaiq", style:"arrogante", emotion:"sereno", avatar: makeAvatarSVG('OC_Prvaiq','arrogante',240) },
{ name:"OC_Ozcnnk", style:"possessivo", emotion:"sombrio", avatar: makeAvatarSVG('OC_Ozcnnk','possessivo',240) },
{ name:"OC_Dbnebo", style:"romântico", emotion:"sombrio", avatar: makeAvatarSVG('OC_Dbnebo','romântico',240) },
{ name:"OC_Ekmjom", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Ekmjom','engraçado',240) },
{ name:"OC_Trwlux", style:"engraçado", emotion:"alegre", avatar: makeAvatarSVG('OC_Trwlux','engraçado',240) },
{ name:"OC_Cgzxyo", style:"possessivo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Cgzxyo','possessivo',240) },
{ name:"OC_Uspqmx", style:"frio", emotion:"pensativo", avatar: makeAvatarSVG('OC_Uspqmx','frio',240) },
{ name:"OC_Gwyfve", style:"misterioso", emotion:"sombrio", avatar: makeAvatarSVG('OC_Gwyfve','misterioso',240) },
{ name:"OC_Lvezet", style:"possessivo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Lvezet','possessivo',240) },
{ name:"OC_Vjgxea", style:"engraçado", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Vjgxea','engraçado',240) },
{ name:"OC_Hobywk", style:"engraçado", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Hobywk','engraçado',240) },
{ name:"OC_Nonshu", style:"brincalhão", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Nonshu','brincalhão',240) },
{ name:"OC_Mylldd", style:"arrogante", emotion:"sombrio", avatar: makeAvatarSVG('OC_Mylldd','arrogante',240) },
{ name:"OC_Mqaowr", style:"arrogante", emotion:"sereno", avatar: makeAvatarSVG('OC_Mqaowr','arrogante',240) },
{ name:"OC_Olumyz", style:"calmo", emotion:"tímido", avatar: makeAvatarSVG('OC_Olumyz','calmo',240) },
{ name:"OC_Blgnsj", style:"poético", emotion:"tímido", avatar: makeAvatarSVG('OC_Blgnsj','poético',240) },
{ name:"OC_Iiorbp", style:"arrogante", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Iiorbp','arrogante',240) },
{ name:"OC_Wiqgaq", style:"arrogante", emotion:"sereno", avatar: makeAvatarSVG('OC_Wiqgaq','arrogante',240) },
{ name:"OC_Bchmko", style:"romântico", emotion:"sombrio", avatar: makeAvatarSVG('OC_Bchmko','romântico',240) },
{ name:"OC_Kjrrsg", style:"arrogante", emotion:"pensativo", avatar: makeAvatarSVG('OC_Kjrrsg','arrogante',240) },
{ name:"OC_Ydvxqd", style:"misterioso", emotion:"alegre", avatar: makeAvatarSVG('OC_Ydvxqd','misterioso',240) },
{ name:"OC_Ismsbb", style:"frio", emotion:"melancólico", avatar: makeAvatarSVG('OC_Ismsbb','frio',240) },
{ name:"OC_Gvcxog", style:"romântico", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Gvcxog','romântico',240) },
{ name:"OC_Gfmisa", style:"misterioso", emotion:"pensativo", avatar: makeAvatarSVG('OC_Gfmisa','misterioso',240) },
{ name:"OC_Xleyfp", style:"arrogante", emotion:"alegre", avatar: makeAvatarSVG('OC_Xleyfp','arrogante',240) },
{ name:"OC_Fzylcp", style:"fofo", emotion:"sereno", avatar: makeAvatarSVG('OC_Fzylcp','fofo',240) },
{ name:"OC_Pxvbju", style:"engraçado", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Pxvbju','engraçado',240) },
{ name:"OC_Vqzkne", style:"calmo", emotion:"tímido", avatar: makeAvatarSVG('OC_Vqzkne','calmo',240) },
{ name:"OC_Bwetbr", style:"poético", emotion:"sereno", avatar: makeAvatarSVG('OC_Bwetbr','poético',240) },
{ name:"OC_Sqsbur", style:"possessivo", emotion:"alegre", avatar: makeAvatarSVG('OC_Sqsbur','possessivo',240) },
{ name:"OC_Llrqwt", style:"misterioso", emotion:"feliz", avatar: makeAvatarSVG('OC_Llrqwt','misterioso',240) },
{ name:"OC_Pdsuyu", style:"poético", emotion:"tímido", avatar: makeAvatarSVG('OC_Pdsuyu','poético',240) },
{ name:"OC_Errkce", style:"romântico", emotion:"sombrio", avatar: makeAvatarSVG('OC_Errkce','romântico',240) },
{ name:"OC_Gnqlsv", style:"poético", emotion:"alegre", avatar: makeAvatarSVG('OC_Gnqlsv','poético',240) },
{ name:"OC_Lvndsa", style:"frio", emotion:"tímido", avatar: makeAvatarSVG('OC_Lvndsa','frio',240) },
{ name:"OC_Qhisgm", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Qhisgm','engraçado',240) },
{ name:"OC_Akzaxp", style:"romântico", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Akzaxp','romântico',240) },
{ name:"OC_Hpojux", style:"fofo", emotion:"alegre", avatar: makeAvatarSVG('OC_Hpojux','fofo',240) },
{ name:"OC_Jolegi", style:"calmo", emotion:"tímido", avatar: makeAvatarSVG('OC_Jolegi','calmo',240) },
{ name:"OC_Dnxepa", style:"possessivo", emotion:"melancólico", avatar: makeAvatarSVG('OC_Dnxepa','possessivo',240) },
{ name:"OC_Qswnlk", style:"arrogante", emotion:"sereno", avatar: makeAvatarSVG('OC_Qswnlk','arrogante',240) },
{ name:"OC_Qaookg", style:"fofo", emotion:"sereno", avatar: makeAvatarSVG('OC_Qaookg','fofo',240) },
{ name:"OC_Yfcfed", style:"engraçado", emotion:"feliz", avatar: makeAvatarSVG('OC_Yfcfed','engraçado',240) },
{ name:"OC_Ufjqim", style:"brincalhão", emotion:"tímido", avatar: makeAvatarSVG('OC_Ufjqim','brincalhão',240) },
{ name:"OC_Jbzmil", style:"romântico", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Jbzmil','romântico',240) },
{ name:"OC_Jubrvp", style:"poético", emotion:"tímido", avatar: makeAvatarSVG('OC_Jubrvp','poético',240) },
{ name:"OC_Ipugtx", style:"frio", emotion:"sombrio", avatar: makeAvatarSVG('OC_Ipugtx','frio',240) },
{ name:"OC_Syinhi", style:"misterioso", emotion:"alegre", avatar: makeAvatarSVG('OC_Syinhi','misterioso',240) },
{ name:"OC_Gkqymq", style:"engraçado", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Gkqymq','engraçado',240) },
{ name:"OC_Admriz", style:"frio", emotion:"sereno", avatar: makeAvatarSVG('OC_Admriz','frio',240) },
{ name:"OC_Vrlpiu", style:"romântico", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Vrlpiu','romântico',240) },
{ name:"OC_Jwvurn", style:"arrogante", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Jwvurn','arrogante',240) },
{ name:"OC_Ifivne", style:"possessivo", emotion:"sombrio", avatar: makeAvatarSVG('OC_Ifivne','possessivo',240) },
{ name:"OC_Cobldo", style:"calmo", emotion:"melancólico", avatar: makeAvatarSVG('OC_Cobldo','calmo',240) },
{ name:"OC_Qdkasz", style:"calmo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Qdkasz','calmo',240) },
{ name:"OC_Plnnaj", style:"calmo", emotion:"feliz", avatar: makeAvatarSVG('OC_Plnnaj','calmo',240) },
{ name:"OC_Rqcvgb", style:"arrogante", emotion:"alegre", avatar: makeAvatarSVG('OC_Rqcvgb','arrogante',240) },
{ name:"OC_Tbqmid", style:"frio", emotion:"alegre", avatar: makeAvatarSVG('OC_Tbqmid','frio',240) },
{ name:"OC_Pszica", style:"poético", emotion:"pensativo", avatar: makeAvatarSVG('OC_Pszica','poético',240) },
{ name:"OC_Atgrry", style:"frio", emotion:"feliz", avatar: makeAvatarSVG('OC_Atgrry','frio',240) },
{ name:"OC_Ejacor", style:"possessivo", emotion:"sombrio", avatar: makeAvatarSVG('OC_Ejacor','possessivo',240) },
{ name:"OC_Airzmt", style:"romântico", emotion:"sereno", avatar: makeAvatarSVG('OC_Airzmt','romântico',240) },
{ name:"OC_Ngooaf", style:"possessivo", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Ngooaf','possessivo',240) },
{ name:"OC_Xvzzuy", style:"poético", emotion:"sereno", avatar: makeAvatarSVG('OC_Xvzzuy','poético',240) },
{ name:"OC_Jgjqaj", style:"misterioso", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Jgjqaj','misterioso',240) },
{ name:"OC_Scteab", style:"misterioso", emotion:"alegre", avatar: makeAvatarSVG('OC_Scteab','misterioso',240) },
{ name:"OC_Noatuc", style:"romântico", emotion:"sereno", avatar: makeAvatarSVG('OC_Noatuc','romântico',240) },
{ name:"OC_Ucjita", style:"calmo", emotion:"sombrio", avatar: makeAvatarSVG('OC_Ucjita','calmo',240) },
{ name:"OC_Wyqyct", style:"arrogante", emotion:"sombrio", avatar: makeAvatarSVG('OC_Wyqyct','arrogante',240) },
{ name:"OC_Ackyhi", style:"possessivo", emotion:"alegre", avatar: makeAvatarSVG('OC_Ackyhi','possessivo',240) },
{ name:"OC_Lrnqvc", style:"romântico", emotion:"tímido", avatar: makeAvatarSVG('OC_Lrnqvc','romântico',240) },
{ name:"OC_Qzzuhr", style:"misterioso", emotion:"melancólico", avatar: makeAvatarSVG('OC_Qzzuhr','misterioso',240) },
{ name:"OC_Ekphtq", style:"poético", emotion:"sombrio", avatar: makeAvatarSVG('OC_Ekphtq','poético',240) },
{ name:"OC_Agtygo", style:"fofo", emotion:"sereno", avatar: makeAvatarSVG('OC_Agtygo','fofo',240) },
{ name:"OC_Zetwzv", style:"possessivo", emotion:"intenso", avatar: makeAvatarSVG('OC_Zetwzv','possessivo',240) },
{ name:"OC_Estqdn", style:"poético", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Estqdn','poético',240) },
{ name:"OC_Wcmnpc", style:"arrogante", emotion:"tímido", avatar: makeAvatarSVG('OC_Wcmnpc','arrogante',240) },
{ name:"OC_Duxyfh", style:"frio", emotion:"sereno", avatar: makeAvatarSVG('OC_Duxyfh','frio',240) },
{ name:"OC_Dtsasw", style:"misterioso", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Dtsasw','misterioso',240) },
{ name:"OC_Rncgnb", style:"fofo", emotion:"tímido", avatar: makeAvatarSVG('OC_Rncgnb','fofo',240) },
{ name:"OC_Rnlmcr", style:"frio", emotion:"sereno", avatar: makeAvatarSVG('OC_Rnlmcr','frio',240) },
{ name:"OC_Kgkdnl", style:"misterioso", emotion:"alegre", avatar: makeAvatarSVG('OC_Kgkdnl','misterioso',240) },
{ name:"OC_Blrxll", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Blrxll','engraçado',240) },
{ name:"OC_Kudayl", style:"engraçado", emotion:"sereno", avatar: makeAvatarSVG('OC_Kudayl','engraçado',240) },
{ name:"OC_Jwhbli", style:"misterioso", emotion:"intenso", avatar: makeAvatarSVG('OC_Jwhbli','misterioso',240) },
{ name:"OC_Joifnz", style:"romântico", emotion:"alegre", avatar: makeAvatarSVG('OC_Joifnz','romântico',240) },
{ name:"OC_Ksltcj", style:"possessivo", emotion:"tímido", avatar: makeAvatarSVG('OC_Ksltcj','possessivo',240) },
{ name:"OC_Fihjet", style:"poético", emotion:"alegre", avatar: makeAvatarSVG('OC_Fihjet','poético',240) },
{ name:"OC_Mpbjjb", style:"calmo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Mpbjjb','calmo',240) },
{ name:"OC_Ngstwr", style:"fofo", emotion:"feliz", avatar: makeAvatarSVG('OC_Ngstwr','fofo',240) },
{ name:"OC_Vjdyrf", style:"arrogante", emotion:"sombrio", avatar: makeAvatarSVG('OC_Vjdyrf','arrogante',240) },
{ name:"OC_Pngsoi", style:"engraçado", emotion:"alegre", avatar: makeAvatarSVG('OC_Pngsoi','engraçado',240) },
{ name:"OC_Lwapnx", style:"possessivo", emotion:"pensativo", avatar: makeAvatarSVG('OC_Lwapnx','possessivo',240) },
{ name:"OC_Zkosui", style:"brincalhão", emotion:"pensativo", avatar: makeAvatarSVG('OC_Zkosui','brincalhão',240) },
{ name:"OC_Ozdhnb", style:"poético", emotion:"feliz", avatar: makeAvatarSVG('OC_Ozdhnb','poético',240) },
{ name:"OC_Cwxpid", style:"calmo", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Cwxpid','calmo',240) },
{ name:"OC_Ftvklo", style:"fofo", emotion:"alegre", avatar: makeAvatarSVG('OC_Ftvklo','fofo',240) },
{ name:"OC_Wgjmvh", style:"frio", emotion:"alegre", avatar: makeAvatarSVG('OC_Wgjmvh','frio',240) },
{ name:"OC_Zmisci", style:"frio", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Zmisci','frio',240) },
{ name:"OC_Qkwozw", style:"possessivo", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Qkwozw','possessivo',240) },
{ name:"OC_Kxfuzf", style:"arrogante", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Kxfuzf','arrogante',240) },
{ name:"OC_Iggngf", style:"brincalhão", emotion:"tímido", avatar: makeAvatarSVG('OC_Iggngf','brincalhão',240) },
{ name:"OC_Serwrz", style:"misterioso", emotion:"pensativo", avatar: makeAvatarSVG('OC_Serwrz','misterioso',240) },
{ name:"OC_Zlzubw", style:"possessivo", emotion:"melancólico", avatar: makeAvatarSVG('OC_Zlzubw','possessivo',240) },
{ name:"OC_Xzmzfy", style:"poético", emotion:"tímido", avatar: makeAvatarSVG('OC_Xzmzfy','poético',240) },
{ name:"OC_Obipdh", style:"romântico", emotion:"alegre", avatar: makeAvatarSVG('OC_Obipdh','romântico',240) },
{ name:"OC_Tjviur", style:"brincalhão", emotion:"alegre", avatar: makeAvatarSVG('OC_Tjviur','brincalhão',240) },
{ name:"OC_Lqmovt", style:"arrogante", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Lqmovt','arrogante',240) },
{ name:"OC_Fhhvwa", style:"romântico", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Fhhvwa','romântico',240) },
{ name:"OC_Dskpmd", style:"romântico", emotion:"pensativo", avatar: makeAvatarSVG('OC_Dskpmd','romântico',240) },
{ name:"OC_Ueuuxr", style:"misterioso", emotion:"apaixonado", avatar: makeAvatarSVG('OC_Ueuuxr','misterioso',240) },
{ name:"OC_Wfwguu", style:"possessivo", emotion:"melancólico", avatar: makeAvatarSVG('OC_Wfwguu','possessivo',240) },
{ name:"OC_Ncnzyy", style:"frio", emotion:"alegre", avatar: makeAvatarSVG('OC_Ncnzyy','frio',240) },
{ name:"OC_Gthtmw", style:"brincalhão", emotion:"pensativo", avatar: makeAvatarSVG('OC_Gthtmw','brincalhão',240) },
{ name:"OC_Wgwlhu", style:"fofo", emotion:"tímido", avatar: makeAvatarSVG('OC_Wgwlhu','fofo',240) },
{ name:"OC_Oqpbib", style:"fofo", emotion:"sombrio", avatar: makeAvatarSVG('OC_Oqpbib','fofo',240) },
{ name:"OC_Zuucwg", style:"frio", emotion:"tímido", avatar: makeAvatarSVG('OC_Zuucwg','frio',240) },
{ name:"OC_Xmdvuw", style:"arrogante", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Xmdvuw','arrogante',240) },
{ name:"OC_Imgwwa", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Imgwwa','engraçado',240) },
{ name:"OC_Msdbuz", style:"romântico", emotion:"pensativo", avatar: makeAvatarSVG('OC_Msdbuz','romântico',240) },
{ name:"OC_Jtvcxc", style:"fofo", emotion:"alegre", avatar: makeAvatarSVG('OC_Jtvcxc','fofo',240) },
{ name:"OC_Kfnyuv", style:"romântico", emotion:"sereno", avatar: makeAvatarSVG('OC_Kfnyuv','romântico',240) },
{ name:"OC_Zonuud", style:"brincalhão", emotion:"feliz", avatar: makeAvatarSVG('OC_Zonuud','brincalhão',240) },
{ name:"OC_Dpdnbd", style:"misterioso", emotion:"feliz", avatar: makeAvatarSVG('OC_Dpdnbd','misterioso',240) },
{ name:"OC_Bedsyl", style:"brincalhão", emotion:"alegre", avatar: makeAvatarSVG('OC_Bedsyl','brincalhão',240) },
{ name:"OC_Pibfml", style:"brincalhão", emotion:"feliz", avatar: makeAvatarSVG('OC_Pibfml','brincalhão',240) },
{ name:"OC_Uadidn", style:"frio", emotion:"feliz", avatar: makeAvatarSVG('OC_Uadidn','frio',240) },
{ name:"OC_Vrrlyp", style:"frio", emotion:"sombrio", avatar: makeAvatarSVG('OC_Vrrlyp','frio',240) },
{ name:"OC_Zqldar", style:"calmo", emotion:"brincalhão", avatar: makeAvatarSVG('OC_Zqldar','calmo',240) },
{ name:"OC_Qhogrm", style:"misterioso", emotion:"sereno", avatar: makeAvatarSVG('OC_Qhogrm','misterioso',240) },
{ name:"OC_Dcdjet", style:"engraçado", emotion:"melancólico", avatar: makeAvatarSVG('OC_Dcdjet','engraçado',240) },
{ name:"OC_Eaenhi", style:"frio", emotion:"pensativo", avatar: makeAvatarSVG('OC_Eaenhi','frio',240) }
];
},
    { name:"Kael", style:"misterioso", emotion:"tímido", avatar: makeAvatarSVG("Kael","misterioso",240) },
    { name:"Lyra", style:"fofo", emotion:"feliz", avatar: makeAvatarSVG("Lyra","fofo",240) },
    { name:"Ryo", style:"engraçado", emotion:"brincalhão", avatar: makeAvatarSVG("Ryo","engraçado",240) }
  ];
  return presets;
}

function usePreset(p){
  // save and select
  const id = Date.now().toString(36);
  const ch = { id, name:p.name, style:p.style, emotion:p.emotion, bio:"", avatar:p.avatar, gender:"random" };
  appState.chars.push(ch);
  saveChars();
  renderGallery();
  selectCharacter(id);
  // unlock chat tab
  document.querySelectorAll(".tabs .tab").forEach(t=> t.classList.remove("locked"));
  document.querySelector('.tabs .tab[data-tab="chat"]').classList.remove('locked');
  // open chat
  document.querySelector('.tabs .tab[data-tab="chat"]').click();
}

function selectCharacter(id){
  appState.selected = id;
  localStorage.setItem(KEY_SELECTED, id);
  document.getElementById("chat").classList.add("active");
  document.querySelectorAll(".tabs .tab").forEach(t=> t.classList.remove("locked"));
  document.querySelector('.tabs .tab[data-tab="chat"]').classList.remove('locked');
  openChat();
}

function tryAutoRestore(){
  const savedUser = loadUser();
  if(savedUser){ appState.user = savedUser; document.getElementById("userLabel").innerText = savedUser; }
  const savedChars = loadChars();
  if(savedChars && savedChars.length){ appState.chars = savedChars; renderGallery(); }
  const sel = localStorage.getItem(KEY_SELECTED);
  if(sel){ appState.selected = sel; }
}

function createCharacterFromForm(){
  const name = document.getElementById("charName").value.trim();
  const desc = document.getElementById("charDesc").value.trim();
  let style = document.getElementById("charStyle").value;
  const emotion = document.getElementById("charEmotion").value;
  const gender = document.getElementById("charGender").value;
  const user = document.getElementById("username").value.trim();
  if(user){ appState.user = user; saveUser(); document.getElementById("userLabel").innerText = user; }
  if(!name && !desc) return alert("Nome ou descrição é necessário");
  if(style==="auto"){
    // derive from description (simple)
    const d = (desc||"").toLowerCase();
    if(d.includes("romant")||d.includes("amor")) style="romântico";
    else if(d.includes("fof")||d.includes("doce")) style="fofo";
    else if(d.includes("sarcas")||d.includes("irônico")) style="engraçado";
    else style = "fofo";
  }
  const avatar = document.getElementById("previewArea").dataset.avatar || makeAvatarSVG(name||"OC", style, 240);
  const id = Date.now().toString(36);
  const ch = { id, name: name||("OC_"+id.slice(-4)), desc, style, emotion, avatar, gender };
  appState.chars.push(ch);
  saveChars();
  renderGallery();
  selectCharacter(id);
}

function createRandomChar(){
  const presets = getPresets();
  const p = presets[Math.floor(Math.random()*presets.length)];
  usePreset(p);
}

function generatePreviewAvatar(){
  const name = document.getElementById("charName").value.trim() || "OC";
  const style = document.getElementById("charStyle").value || "fofo";
  const data = makeAvatarSVG(name, style, 240);
  const preview = document.getElementById("previewArea");
  preview.innerHTML = `<div class="avatar"><img src="${data}" /></div><div><strong>${name}</strong><div class="muted">${style}</div></div>`;
  preview.dataset.avatar = data;
}

function handleAvatarUpload(e){
  const f = e.target.files[0];
  if(!f) return;
  const fr = new FileReader();
  fr.onload = ()=> {
    document.getElementById("previewArea").innerHTML = `<div class="avatar"><img src="${fr.result}" /></div><div><strong>${document.getElementById("charName").value||"OC"}</strong></div>`;
    document.getElementById("previewArea").dataset.avatar = fr.result;
  };
  fr.readAsDataURL(f);
}

// Chat functions
function openChat(){
  const sel = appState.selected;
  if(!sel) return alert("Selecione ou crie um personagem primeiro");
  const ch = appState.chars.find(x=>x.id===sel);
  if(!ch) return;
  document.getElementById("chatName").innerText = ch.name;
  document.getElementById("chatMeta").innerText = `${ch.style} • ${ch.emotion}`;
  document.getElementById("avatarMini").innerHTML = `<img src="${ch.avatar}" />`;
  document.getElementById("chatWallpaper").style.backgroundImage = `url(${ch.avatar})`;
  // load log
  const key = KEY_LOG_PREFIX + (appState.user||"anon");
  const logs = JSON.parse(localStorage.getItem(key) || "{}");
  const arr = logs[ch.id] || [];
  const box = document.getElementById("chatBox");
  box.innerHTML = "";
  arr.forEach(m=>{
    const div = document.createElement("div");
    div.className = "message " + (m.role==="user"?"user":"ai");
    div.innerHTML = `<div class="bubble">${m.text}</div>`;
    box.appendChild(div);
  });
  box.scrollTop = box.scrollHeight;
}

function appendToLog(charId, role, text){
  const key = KEY_LOG_PREFIX + (appState.user||"anon");
  const logs = JSON.parse(localStorage.getItem(key) || "{}");
  logs[charId] = logs[charId] || [];
  logs[charId].push({ ts: Date.now(), role, text });
  localStorage.setItem(key, JSON.stringify(logs));
}

function sendMessage(){
  const input = document.getElementById("userInput");
  const txt = input.value.trim();
  if(!txt) return;
  const box = document.getElementById("chatBox");
  // render user
  const ud = document.createElement("div"); ud.className = "message user"; ud.innerHTML = `<div class="bubble">${txt}</div>`; box.appendChild(ud);
  appendToLog(appState.selected, "user", txt);
  box.scrollTop = box.scrollHeight;
  input.value = "";
  // get character and ask miniAI
  const ch = appState.chars.find(x=>x.id===appState.selected);
  if(!ch) return;
  const reply = generateReply(ch, txt, appState.lang || "pt-BR");
  // small delay + typing
  setTimeout(()=> {
    const ad = document.createElement("div"); ad.className = "message ai"; ad.innerHTML = `<div class="bubble">${reply.replace(/\n\n.*$/,"")}</div>`; box.appendChild(ad);
    appendToLog(appState.selected, "ai", reply);
    box.scrollTop = box.scrollHeight;
    if(appState.tts) speakText(reply.replace(/\n\n.*$/,""), appState.lang || "pt-BR");
  }, 600 + Math.random()*600);
}

function exportLog(charId){
  const key = KEY_LOG_PREFIX + (appState.user||"anon");
  const logs = JSON.parse(localStorage.getItem(key) || "{}");
  const out = logs[charId] || [];
  const blob = new Blob([JSON.stringify(out, null,2)], {type:"application/json"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `fantasia_log_${charId}.json`;
  a.click();
}

// helpers: makeAvatarSVG is provided by avatarGen.js (makeAvatarSVG)
// but include fallback if missing
if(typeof makeAvatarSVG === "undefined") {
  function makeAvatarSVG(n,s,z){ return ""; }
}

document.addEventListener("DOMContentLoaded", ()=> init());
