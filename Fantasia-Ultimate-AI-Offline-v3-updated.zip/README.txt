Fantasia Ultimate AI — Offline v3

Como usar:
1. Extraia todos os arquivos numa pasta.
2. Abra o arquivo `app.html` no Google Chrome (recomendado).
3. Clique em "Entrar" na tela inicial.
4. Use a aba "Criar" para criar personagens (ou gerar aleatórios).
5. Vá na aba "Galera" para ver presets e personagens salvos.
6. Selecione um personagem e abra a aba "Chat" para conversar. A voz (TTS) e logs funcionam offline.

Recursos:
- Galeria de presets (For You)
- Geração offline de avatar (SVG)
- MiniIA local com variação emocional
- Suporte a idiomas (pt-BR, en-US, ja-JP)
- Salvamento automático de personagens e conversas no localStorage
